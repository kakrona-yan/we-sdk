
/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{tsx,html,css}"],
  theme: { extend: {} },
  plugins: []
};
