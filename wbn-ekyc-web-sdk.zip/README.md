
# wbn-ekyc-web-sdk

Framework-agnostic eKYC SDK built with Stencil + Tailwind. Works in React, Vue, Angular, and plain HTML.

## Quick start (pnpm)

```bash
pnpm i
pnpm start
```

Visit http://localhost:3333 to open the demo. Set API url via env or globally:

```html
<script>window.WBNEKYC_API_URL = 'http://localhost:8787';</script>
```

## Usage

```html
<wbn-ekyc-web-sdk license_token="YOUR_LICENSE"></wbn-ekyc-web-sdk>
```

## Build

```bash
pnpm build
```

### Notes

- Only public prop is `license_token`.
- API base URL is resolved from `import.meta.env.VITE_API_URL` or `window.WBNEKYC_API_URL`, fallback `/api`.
- Endpoints expected: `/document`, `/portrait`, `/liveness` (multipart/form-data).
