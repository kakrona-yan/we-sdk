
import { Component, h, State, Event, EventEmitter, Prop } from '@stencil/core';
import { uploadLiveness } from '../../utils/api';

@Component({
  tag: 'face-liveness-check',
  styleUrl: 'face-liveness-check.css',
  shadow: true,
})
export class FaceLivenessCheck {
  @Prop() license_token!: string;
  @Event() done!: EventEmitter<any>;

  @State() stream?: MediaStream;
  @State() busy = false;
  @State() stepIndex = 0;
  private videoEl?: HTMLVideoElement;
  private steps = ['Center your face', 'Blink', 'Turn left', 'Turn right', 'Smile'];

  async componentDidLoad() {
    this.stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user', width: 640, height: 640 }, audio: false });
    if (this.videoEl) {
      this.videoEl.srcObject = this.stream;
      await this.videoEl.play();
    }
  }

  disconnectedCallback() {
    this.stream?.getTracks().forEach(t => t.stop());
  }

  private captureFrame(): Blob {
    const canvas = document.createElement('canvas');
    const size = 400;
    canvas.width = size; canvas.height = size;
    const ctx = canvas.getContext('2d')!;
    ctx.drawImage(this.videoEl as HTMLVideoElement, 0, 0, size, size);
    const data = canvas.toDataURL('image/jpeg', 0.9);
    const bin = atob(data.split(',')[1]);
    const buf = new Uint8Array(bin.length);
    for (let i=0;i<bin.length;i++) buf[i] = bin.charCodeAt(i);
    return new Blob([buf], { type: 'image/jpeg' });
  }

  private async next() {
    if (this.stepIndex < this.steps.length - 1) {
      this.stepIndex += 1;
    } else {
      this.busy = true;
      const captures = [this.captureFrame()];
      const res = await uploadLiveness(captures, this.license_token);
      this.busy = false;
      if (!res.ok) return;
      this.done.emit(res.data || { ok: true });
    }
  }

  render() {
    return (
      <div class="grid gap-3">
        <div class="relative w-72 h-72 mx-auto rounded-full overflow-hidden border-4 border-purple-500">
          <video ref={el => this.videoEl = el as HTMLVideoElement} class="w-full h-full object-cover"></video>
          <div class="pointer-events-none absolute inset-0 rounded-full border-4 border-purple-400 animate-spin-slow"></div>
        </div>
        <style>
          {`@keyframes spin-slow { from{transform:rotate(0)} to{transform:rotate(360deg)} }
            .animate-spin-slow { animation: spin-slow 6s linear infinite; }`}
        </style>
        <p class="text-center font-medium">{this.steps[this.stepIndex]}</p>
        <button class="wbn-btn justify-self-center" disabled={this.busy} onClick={() => this.next()}>
          {this.stepIndex < this.steps.length - 1 ? 'Next' : (this.busy ? 'Submitting...' : 'Finish')}
        </button>
      </div>
    );
  }
}
