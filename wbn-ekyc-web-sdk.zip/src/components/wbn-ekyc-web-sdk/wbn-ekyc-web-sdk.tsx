
import { Component, h, Prop, State, Event, EventEmitter } from '@stencil/core';

@Component({
  tag: 'wbn-ekyc-web-sdk',
  styleUrl: 'wbn-ekyc-web-sdk.css',
  shadow: true,
})
export class WbnEkycWebSdk {
  /** Required license token */
  @Prop() license_token!: string;

  /** Emits final result */
  @Event() completed!: EventEmitter<any>;

  @State() step: 'document' | 'portrait' | 'liveness' | 'done' = 'document';
  @State() results: any = {};

  private handleDocDone = (e: CustomEvent<any>) => {
    this.results.document = e.detail;
    this.step = 'portrait';
  };
  private handlePortraitDone = (e: CustomEvent<any>) => {
    this.results.portrait = e.detail;
    this.step = 'liveness';
  };
  private handleLivenessDone = (e: CustomEvent<any>) => {
    this.results.liveness = e.detail;
    this.step = 'done';
    this.completed.emit(this.results);
  };

  render() {
    return (
      <div class="wbn-card grid gap-4">
        <div>
          <h2 class="text-xl font-semibold">eKYC Verification</h2>
          <p class="wbn-muted">Step: {this.step}</p>
        </div>
        {this.step === 'document' && (
          <document-upload license_token={this.license_token} onDone={this.handleDocDone}></document-upload>
        )}
        {this.step === 'portrait' && (
          <portrait-upload license_token={this.license_token} onDone={this.handlePortraitDone}></portrait-upload>
        )}
        {this.step === 'liveness' && (
          <face-liveness-check license_token={this.license_token} onDone={this.handleLivenessDone}></face-liveness-check>
        )}
        {this.step === 'done' && (
          <div class="p-4 border rounded-xl">
            <p class="font-medium text-green-600">All steps completed.</p>
            <pre class="text-xs bg-gray-100 p-2 rounded overflow-auto">{JSON.stringify(this.results, null, 2)}</pre>
          </div>
        )}
      </div>
    );
  }
}
