
import { Component, h, State, Event, EventEmitter, Prop } from '@stencil/core';
import { uploadPortrait } from '../../utils/api';

@Component({
  tag: 'portrait-upload',
  styleUrl: 'portrait-upload.css',
  shadow: true,
})
export class PortraitUpload {
  @Prop() license_token!: string;
  @Event() done!: EventEmitter<any>;
  @State() file?: File;
  @State() busy = false;
  @State() message = '';

  private onChange = (e: any) => {
    const f = e.target.files?.[0];
    if (f) this.file = f;
  };

  private async onSubmit() {
    if (!this.file) { this.message = 'Choose a file first'; return; }
    this.busy = true; this.message = '';
    const res = await uploadPortrait(this.file, this.license_token);
    this.busy = false;
    if (!res.ok) { this.message = res.message || 'Upload failed'; return; }
    this.done.emit(res.data || { ok: true });
  }

  render() {
    return (
      <div class="grid gap-3">
        <div class="relative w-72 h-72 mx-auto rounded-full overflow-hidden border-4 border-purple-500 flex items-center justify-center bg-orange-200">
          <input class="absolute inset-0 opacity-0 cursor-pointer" type="file" accept="image/*" capture="user" onChange={this.onChange.bind(this)} />
          <span class="text-sm font-medium text-purple-700">Tap to choose selfie</span>
          <div class="pointer-events-none absolute inset-0 rounded-full border-4 border-purple-400 animate-spin-slow"></div>
        </div>
        <style>
          {`@keyframes spin-slow { from{transform:rotate(0)} to{transform:rotate(360deg)} }
            .animate-spin-slow { animation: spin-slow 6s linear infinite; }`}
        </style>
        <button class="wbn-btn" disabled={this.busy} onClick={this.onSubmit.bind(this)}>
          {this.busy ? 'Uploading...' : 'Continue'}
        </button>
        {this.message && <p class="text-sm text-red-600">{this.message}</p>}
      </div>
    );
  }
}
