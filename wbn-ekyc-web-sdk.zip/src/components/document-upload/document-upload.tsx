
import { Component, h, State, Event, EventEmitter, Prop } from '@stencil/core';
import { uploadDocument } from '../../utils/api';

@Component({
  tag: 'document-upload',
  styleUrl: 'document-upload.css',
  shadow: true,
})
export class DocumentUpload {
  @Prop() license_token!: string;
  @Event() done!: EventEmitter<any>;
  @State() file?: File;
  @State() busy = false;
  @State() message = '';

  private onChange = (e: any) => {
    const f = e.target.files?.[0];
    if (f) this.file = f;
  };

  private async onSubmit() {
    if (!this.file) { this.message = 'Choose a file first'; return; }
    this.busy = true; this.message = '';
    const res = await uploadDocument(this.file, this.license_token);
    this.busy = false;
    if (!res.ok) { this.message = res.message || 'Upload failed'; return; }
    this.done.emit(res.data || { ok: true });
  }

  render() {
    return (
      <div class="grid gap-3">
        <div class="border-2 border-dashed rounded-2xl p-6 text-center">
          <p class="font-medium mb-2">Document image</p>
          <input type="file" accept="image/*,.pdf" onChange={this.onChange.bind(this)} />
        </div>
        <button class="wbn-btn" disabled={this.busy} onClick={this.onSubmit.bind(this)}>
          {this.busy ? 'Uploading...' : 'Continue'}
        </button>
        {this.message && <p class="text-sm text-red-600">{this.message}</p>}
      </div>
    );
  }
}
