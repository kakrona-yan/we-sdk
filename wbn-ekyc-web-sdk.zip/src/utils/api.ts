
import { API_URL } from '../env';

export type UploadResponse = { ok: boolean; message?: string; data?: any };

async function uploadForm(path: string, form: FormData): Promise<UploadResponse> {
  const res = await fetch(`${API_URL}${path}`, {
    method: 'POST',
    body: form
  });
  if (!res.ok) {
    return { ok: false, message: `HTTP ${res.status}` };
  }
  try {
    const data = await res.json();
    return { ok: true, data };
  } catch (e) {
    return { ok: true };
  }
}

export async function uploadDocument(file: File, license_token: string) {
  const form = new FormData();
  form.append('document', file);
  form.append('license_token', license_token);
  return uploadForm('/document', form);
}

export async function uploadPortrait(file: File, license_token: string) {
  const form = new FormData();
  form.append('portrait', file);
  form.append('license_token', license_token);
  return uploadForm('/portrait', form);
}

export async function uploadLiveness(captures: Blob[], license_token: string) {
  const form = new FormData();
  captures.forEach((b, i) => form.append('capture_' + i, b, `frame_${i}.jpg`));
  form.append('license_token', license_token);
  return uploadForm('/liveness', form);
}
