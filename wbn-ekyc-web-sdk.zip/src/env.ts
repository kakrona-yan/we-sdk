
/**
 * API base URL resolution:
 * - Prefer Vite-style env var VITE_API_URL if present at build time
 * - Else, use window.WBNEKYC_API_URL injected at runtime
 * - Else, default to /api
 */
export const API_URL: string =
  (typeof import.meta !== 'undefined' && (import.meta as any).env && (import.meta as any).env.VITE_API_URL) ||
  ((globalThis as any).WBNEKYC_API_URL) ||
  '/api';
