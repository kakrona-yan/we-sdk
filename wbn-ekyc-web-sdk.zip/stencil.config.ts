
import { Config } from '@stencil/core';

export const config: Config = {
  namespace: 'wbn-ekyc-web-sdk',
  srcDir: 'src',
  globalStyle: 'src/global/app.css',
  outputTargets: [
    { type: 'dist', esmLoaderPath: '../loader' },
    { type: 'dist-custom-elements-bundle' },
    { type: 'www', serviceWorker: null }
  ],
  devServer: {
    openBrowser: false,
    port: 3333
  }
};
