# Doc Reader SDK (Full)
- **Stencil.js** core web components
- **React wrapper** with `react-webcam` and simple animations
- **TailwindCSS** styling for the UI similar to Regula
- **License token as prop** — `<doc-reader-sdk license-token="YOUR_JWT" api-url="http://localhost:3001"></doc-reader-sdk>`
- All requests attach header `license_token: <prop>`

## Install & Build
```bash
npm i
npm run build
# or develop stencil
npm run dev
```
