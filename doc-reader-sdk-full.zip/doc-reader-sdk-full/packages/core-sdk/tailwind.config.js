/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./src/**/*.{tsx,ts,css,html}'],
  theme: { extend: {} },
  plugins: []
}
