import { Component, h, State, Event, EventEmitter, Prop } from '@stencil/core';
import { sdkFetch } from '../../utils/fetch';

@Component({
  tag: 'face-liveness-check',
  styleUrl: 'face-liveness-check.css',
  shadow: true,
})
export class FaceLivenessCheck {
  @Prop({ attribute: 'api-url' }) apiUrl: string;
  @Prop({ attribute: 'license-token' }) licenseToken: string;

  @State() step = 0;
  @State() loading = false;
  @State() error?: string;
  @Event() done: EventEmitter<any>;

  private steps = ['Neutral face', 'Blink', 'Turn head left', 'Smile'];
  private stream?: MediaStream;
  private videoEl?: HTMLVideoElement;

  async componentDidLoad() {
    this.stream = await navigator.mediaDevices.getUserMedia({ video: true });
    setTimeout(() => {
      this.videoEl = (this as any).host.shadowRoot.querySelector('video');
      if (this.videoEl) this.videoEl.srcObject = this.stream as any;
    }, 0);
  }

  disconnectedCallback() {
    this.stream?.getTracks().forEach(t => t.stop());
  }

  private async captureAndSend() {
    if (!this.videoEl) return;
    const canvas = document.createElement('canvas');
    canvas.width = this.videoEl.videoWidth; canvas.height = this.videoEl.videoHeight;
    const ctx = canvas.getContext('2d')!; ctx.drawImage(this.videoEl, 0, 0);
    const dataUrl = canvas.toDataURL('image/jpeg', 0.85);

    this.loading = true; this.error = undefined;
    try {
      const out = await sdkFetch(this.apiUrl, this.licenseToken, '/liveness', {
        method: 'POST',
        body: JSON.stringify({ image: dataUrl, step: this.steps[this.step] })
      });
      this.loading = false;
      return out;
    } catch (e: any) {
      this.loading = false;
      this.error = e.message;
      return null;
    }
  }

  private async next() {
    const res = await this.captureAndSend();
    if (!res) return;
    if (this.step < this.steps.length - 1) this.step++;
    else this.done.emit(res);
  }

  render() {
    return (
      <div class="rounded-2xl border p-4 bg-white/80 flex flex-col items-center gap-3">
        <h3 class="text-xl font-semibold">Face liveness check</h3>
        <div class="relative w-64 h-64 rounded-full overflow-hidden border-8 border-gray-300">
          <video autoplay playsinline class="w-full h-full object-cover"></video>
          <div class="spinner"></div>
        </div>
        <div>{this.steps[this.step]}</div>
        <button class="px-4 py-2 rounded bg-black text-white" onClick={() => this.next()} disabled={this.loading}>
          {this.step < this.steps.length - 1 ? 'Next' : 'Finish'}
        </button>
        {this.loading && <div class="text-sm">Verifying…</div>}
        {this.error && <div class="text-sm text-red-600">{this.error}</div>}
      </div>
    );
  }
}
