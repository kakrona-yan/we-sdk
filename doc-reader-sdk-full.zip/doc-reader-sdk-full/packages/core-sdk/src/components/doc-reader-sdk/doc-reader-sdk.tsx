import { Component, Prop, h, State, Event, EventEmitter } from '@stencil/core';
import { sdkFetch } from '../../utils/fetch';

@Component({
  tag: 'doc-reader-sdk',
  styleUrl: 'doc-reader-sdk.css',
  shadow: true,
})
export class DocReaderSdk {
  /** Backend base URL */
  @Prop({ attribute: 'api-url' }) apiUrl: string;
  /** JWT license token header value */
  @Prop({ attribute: 'license-token' }) licenseToken: string;
  /** Optional callback */
  @Event() completed: EventEmitter<any>;

  @State() docResult?: any;
  @State() portraitResult?: any;
  @State() livenessResult?: any;
  @State() step: 'document' | 'portrait' | 'liveness' | 'verifying' | 'done' = 'document';
  @State() error?: string;

  private async finalize() {
    this.step = 'verifying';
    try {
      const verify = await sdkFetch(this.apiUrl, this.licenseToken, '/license/verify', {
        method: 'POST',
        body: JSON.stringify({ license_token: this.licenseToken })
      });
      const result = { document: this.docResult, portrait: this.portraitResult, liveness: this.livenessResult, verify };
      this.completed.emit(result);
      this.step = 'done';
    } catch (e: any) {
      this.error = e.message;
      this.completed.emit({ error: e.message });
      this.step = 'done';
    }
  }

  private onDocDone = (e: CustomEvent) => {
    this.docResult = e.detail;
    this.step = 'portrait';
  }

  private onPortraitDone = (e: CustomEvent) => {
    this.portraitResult = e.detail;
    this.step = 'liveness';
  }

  private onLivenessDone = (e: CustomEvent) => {
    this.livenessResult = e.detail;
    this.finalize();
  }

  render() {
    return (
      <div class="grid md:grid-cols-2 gap-6">
        {this.step !== 'done' && (
          <>
            <document-upload class="block" api-url={this.apiUrl} license-token={this.licenseToken} onDone={this.onDocDone} />
            <portrait-upload class="block" api-url={this.apiUrl} license-token={this.licenseToken} onDone={this.onPortraitDone} />
            {this.step === 'liveness' && (
              <div class="md:col-span-2">
                <face-liveness-check api-url={this.apiUrl} license-token={this.licenseToken} onDone={this.onLivenessDone} />
              </div>
            )}
          </>
        )}
        {this.step === 'done' && <div class="md:col-span-2 p-4 rounded-xl border">Completed. {this.error ? <span class="text-red-600">{this.error}</span> : 'Success'}.</div>}
      </div>
    );
  }
}
