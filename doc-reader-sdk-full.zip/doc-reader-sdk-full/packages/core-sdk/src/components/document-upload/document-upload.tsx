import { Component, h, State, Event, EventEmitter, Prop } from '@stencil/core';
import { sdkFetch } from '../../utils/fetch';

@Component({
  tag: 'document-upload',
  styleUrl: 'document-upload.css',
  shadow: true,
})
export class DocumentUpload {
  @Prop({ attribute: 'api-url' }) apiUrl: string;
  @Prop({ attribute: 'license-token' }) licenseToken: string;

  @State() preview?: string;
  @State() usingCamera = false;
  @State() urlInput = '';
  @State() loading = false;
  @State() error?: string;

  @Event() done: EventEmitter<any>;

  private async submitMeta(meta: any) {
    this.loading = true;
    this.error = undefined;
    try {
      const out = await sdkFetch(this.apiUrl, this.licenseToken, '/document', { method: 'POST', body: JSON.stringify(meta) });
      this.done.emit(out);
    } catch (e: any) {
      this.error = e.message;
    } finally {
      this.loading = false;
    }
  }

  private onFile = async (file: File) => {
    if (!/(jpe?g|png|pdf)$/i.test(file.name)) {
      this.error = 'Unsupported file type'; return;
    }
    this.preview = URL.createObjectURL(file);
    await this.submitMeta({ filename: file.name, type: file.type, size: file.size });
  }

  private onURL = async () => {
    if (!this.urlInput) return;
    this.preview = this.urlInput;
    await this.submitMeta({ url: this.urlInput });
  }

  private stream?: MediaStream;
  private videoEl?: HTMLVideoElement;

  private async startCamera() {
    this.stream = await navigator.mediaDevices.getUserMedia({ video: true });
    this.usingCamera = true;
    setTimeout(() => {
      this.videoEl = (this as any).host.shadowRoot.querySelector('video');
      if (this.videoEl) this.videoEl.srcObject = this.stream as any;
    }, 0);
  }
  private async takePhoto() {
    if (!this.videoEl) return;
    const canvas = document.createElement('canvas');
    canvas.width = this.videoEl.videoWidth; canvas.height = this.videoEl.videoHeight;
    const ctx = canvas.getContext('2d')!; ctx.drawImage(this.videoEl, 0, 0);
    const dataUrl = canvas.toDataURL('image/jpeg', 0.9);
    this.preview = dataUrl;
    await this.submitMeta({ captured: true, mime: 'image/jpeg', length: dataUrl.length });
    this.stopCamera();
  }
  private stopCamera() {
    this.stream?.getTracks().forEach(t => t.stop());
    this.usingCamera = false;
  }

  render() {
    return (
      <div class="rounded-2xl border p-4 bg-white/80">
        <h3 class="text-xl font-semibold mb-3">Document image</h3>
        <div class="flex items-center justify-between">
          <button class="w-full border-2 rounded-full py-2 mb-3 flex items-center justify-center gap-2" onClick={() => this.startCamera()}>📷 Take a photo</button>
        </div>
        <div class="border-2 border-dashed rounded-2xl p-6 text-center">
          <p class="mb-2 opacity-80">Drag your document image</p>
          <p class="my-2 opacity-60">— OR —</p>
          <div class="flex items-center justify-center gap-2">
            <input id="docfile" type="file" accept="image/*,application/pdf" class="hidden" onChange={(e: any) => this.onFile(e.target.files[0])} />
            <label htmlFor="docfile" class="px-4 py-2 border rounded-lg cursor-pointer">Upload a file</label>
          </div>
        </div>
        <div class="mt-3 flex gap-2">
          <input class="flex-1 border rounded-lg px-3 py-2" placeholder="Use image URL" value={this.urlInput} onInput={(e: any) => this.urlInput = e.target.value} />
          <button class="px-3 py-2 border rounded-lg" onClick={() => this.onURL()}>GO</button>
        </div>
        {this.usingCamera && (
          <div class="mt-3 space-y-2">
            <video autoplay playsinline class="w-full rounded-lg"></video>
            <div class="flex gap-2">
              <button class="px-3 py-2 rounded bg-black text-white" onClick={() => this.takePhoto()}>Capture</button>
              <button class="px-3 py-2 rounded border" onClick={() => this.stopCamera()}>Cancel</button>
            </div>
          </div>
        )}
        {this.preview && <img src={this.preview} class="mt-3 rounded-xl max-h-60 mx-auto" />}
        {this.loading && <div class="mt-2 text-sm">Uploading…</div>}
        {this.error && <div class="mt-2 text-sm text-red-600">{this.error}</div>}
      </div>
    );
  }
}
