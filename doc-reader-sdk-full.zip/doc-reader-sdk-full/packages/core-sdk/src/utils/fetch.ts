export async function sdkFetch(apiUrl: string, licenseToken: string, path: string, opts: RequestInit = {}) {
  const headers = new Headers(opts.headers || {});
  headers.set('license_token', licenseToken || '');
  if (!headers.has('content-type')) headers.set('content-type', 'application/json');
  const res = await fetch(`${apiUrl}${path}`, { ...opts, headers });
  const ct = res.headers.get('content-type') || '';
  const body = ct.includes('application/json') ? await res.json() : await res.text();
  if (!res.ok) throw new Error((body && body.message) || `HTTP ${res.status}`);
  return body;
}
