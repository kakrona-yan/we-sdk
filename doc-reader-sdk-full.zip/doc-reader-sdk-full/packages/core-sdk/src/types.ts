export interface ApiResult<T=any> { ok?: boolean; data?: T; [k: string]: any }
