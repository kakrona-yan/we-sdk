import { Config } from '@stencil/core';
import { reactOutputTarget } from '@stencil/react-output-target';

export const config: Config = {
  namespace: 'docreadersdk',
  globalStyle: 'src/global/tailwind.css',
  outputTargets: [
    reactOutputTarget({
      componentCorePackage: '@doc/sdk',
      proxiesFile: '../react-wrapper/src/components/stencil-generated/index.ts'
    }),
    { type: 'dist' },
    { type: 'dist-custom-elements' },
    { type: 'www', serviceWorker: null }
  ],
};
