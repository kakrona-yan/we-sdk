# License + Contact Management (NestJS + Prisma) with Secure Transport (Next.js)

Monorepo with:
- **backend/** NestJS + Prisma license issuance/verification, Passport guard, AES-256-CBC + gzip transport
- **frontend/** Next.js demo with a secure fetch wrapper

## Setup

### 1) Backend
```bash
cd backend
cp .env.example .env
# Fill: JWT_PRIVATE_KEY_BASE64, JWT_PUBLIC_KEY_BASE64, AES_KEY_BASE64, AES_IV_BASE64, DATABASE_URL
npm i
npx prisma generate
npm run prisma:migrate
npm run seed
npm run start:dev
```

### 2) Frontend
```bash
cd ../frontend
cp .env.example .env.local
# Fill: NEXT_PUBLIC_API_BASE, NEXT_PUBLIC_AES_KEY_BASE64, NEXT_PUBLIC_AES_IV_BASE64
npm i
npm run dev
```

### 3) Issue a token
```bash
# From backend
npm run issue:token
```

Paste the printed `license_token` into the frontend page input.

## Notes
- For secure endpoints, send header `x-secure-payload: 1` and body `{ data: <base64> }`.
- Protected routes require `license_token` header.
