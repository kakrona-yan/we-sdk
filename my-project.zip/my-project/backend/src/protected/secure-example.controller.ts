import { Body, Controller, Post, UseGuards, UseInterceptors } from '@nestjs/common';
import { LicenseGuard } from '../license/guards/license.guard';
import { SecureInterceptor } from '../security/secure.interceptor';

@Controller('secure')
@UseGuards(LicenseGuard)
@UseInterceptors(SecureInterceptor)
export class SecureExampleController {
  @Post('echo')
  echo(@Body() body: any) {
    // Body is already decrypted JSON
    return { received: body };
  }
}
