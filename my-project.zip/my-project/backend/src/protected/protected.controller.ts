import { Controller, Get, Req, UseGuards } from '@nestjs/common';
import { LicenseGuard } from '../license/guards/license.guard';

@Controller('protected')
export class ProtectedController {
  @Get('data')
  @UseGuards(LicenseGuard)
  getData(@Req() req: any) {
    return { message: 'Valid license', license: req.license };
  }
}
