import { Body, Controller, Post } from '@nestjs/common';
import { LicenseService } from './license.service';

@Controller('license')
export class LicenseController {
  constructor(private readonly service: LicenseService) {}

  @Post('verify')
  async verify(@Body('license_token') token: string) {
    const { claims, license } = await this.service.verifyToken(token);
    return { ok: true, claims, license };
  }
}
