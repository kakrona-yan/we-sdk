import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { LicenseService } from './license.service';
import { LicenseController } from './license.controller';
import { LicenseStrategy } from './strategies/license.strategy';

function fromB64(name: string) {
  const val = process.env[name];
  if (!val) throw new Error(`${name} not set`);
  return Buffer.from(val, 'base64').toString('utf8');
}

@Module({
  imports: [
    JwtModule.register({
      privateKey: fromB64('JWT_PRIVATE_KEY_BASE64'),
      publicKey: fromB64('JWT_PUBLIC_KEY_BASE64'),
      signOptions: { algorithm: 'RS256', expiresIn: process.env.JWT_EXPIRES_IN || '30d' },
      verifyOptions: { algorithms: ['RS256'] },
    }),
  ],
  providers: [LicenseService, LicenseStrategy],
  controllers: [LicenseController],
  exports: [LicenseService],
})
export class LicenseModule {}
