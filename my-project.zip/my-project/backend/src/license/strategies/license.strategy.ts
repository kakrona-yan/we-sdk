import { Injectable, UnauthorizedException } from '@nestjs/common';
import { PassportStrategy } from '@nestjs/passport';
import { Strategy } from 'passport-custom';
import { LicenseService } from '../license.service';

@Injectable()
export class LicenseStrategy extends PassportStrategy(Strategy, 'license') {
  constructor(private readonly license: LicenseService) {
    super();
  }

  async validate(req: any): Promise<any> {
    const token: string | undefined = req.headers['license_token'] as string;
    if (!token) throw new UnauthorizedException('license_token header missing');
    const { claims, license } = await this.license.verifyToken(token);
    req.license = { claims, license };
    return { claims, license };
  }
}
