import { Injectable, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { PrismaService } from '../prisma/prisma.service';
import * as z from 'zod';

const ClaimSchema = z.object({
  iss: z.string(),
  contact_id: z.string(),
  is_biller: z.boolean(),
  channel: z.string(),
  product_type: z.string(),
  exp: z.number().optional(),
  iat: z.number().optional(),
});

@Injectable()
export class LicenseService {
  constructor(private prisma: PrismaService, private jwt: JwtService) {}

  async generateToken(licenseId: string) {
    const license = await this.prisma.clientLicense.findUnique({
      where: { licenseKey: licenseId },
      include: { contact: true },
    });
    if (!license) throw new UnauthorizedException('License not found');

    const payload = {
      iss: license.licenseKey,
      contact_id: license.contactId,
      is_biller: license.isBiller,
      channel: license.channel,
      product_type: license.productType,
    };

    return this.jwt.signAsync(payload);
  }

  async verifyToken(token: string) {
    try {
      const decoded = await this.jwt.verifyAsync(token);
      const claims = ClaimSchema.parse(decoded);

      const lic = await this.prisma.clientLicense.findUnique({
        where: { licenseKey: claims.iss },
        include: { contact: true },
      });
      if (!lic) throw new UnauthorizedException('License not found');
      if (new Date(lic.expiresAt).getTime() <= Date.now()) {
        throw new UnauthorizedException('License expired');
      }
      return { claims, license: lic };
    } catch (e) {
      throw new UnauthorizedException('Invalid or expired license token');
    }
  }
}
