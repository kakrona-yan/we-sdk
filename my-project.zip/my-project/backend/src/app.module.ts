import { Module } from '@nestjs/common';
import { PrismaModule } from './prisma/prisma.module';
import { LicenseModule } from './license/license.module';
import { ProtectedModule } from './protected/protected.module';
import { SecurityModule } from './security/security.module';

@Module({
  imports: [PrismaModule, LicenseModule, ProtectedModule, SecurityModule],
})
export class AppModule {}
