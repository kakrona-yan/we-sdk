import { CallHandler, ExecutionContext, Injectable, NestInterceptor } from '@nestjs/common';
import { Observable, map } from 'rxjs';
import { AesService } from './aes.service';

@Injectable()
export class SecureInterceptor implements NestInterceptor {
  constructor(private aes: AesService) {}

  intercept(ctx: ExecutionContext, next: CallHandler): Observable<any> {
    const req = ctx.switchToHttp().getRequest();
    const isSecure = req.headers['x-secure-payload'] === '1';
    if (isSecure) {
      const packed = req.body?.data;
      if (typeof packed === 'string') {
        req.body = this.aes.unwrap(packed);
      }
    }
    return next.handle().pipe(
      map((data) => {
        if (isSecure) return { data: this.aes.wrap(data) };
        return data;
      }),
    );
  }
}
