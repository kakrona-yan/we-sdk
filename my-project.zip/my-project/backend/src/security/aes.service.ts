import { Injectable } from '@nestjs/common';
import * as zlib from 'zlib';
import * as crypto from 'crypto';

function fromB64(name: string) {
  const v = process.env[name];
  if (!v) throw new Error(`${name} not set`);
  return Buffer.from(v, 'base64');
}

@Injectable()
export class AesService {
  private key = fromB64('AES_KEY_BASE64'); // 32 bytes
  private iv = fromB64('AES_IV_BASE64');   // 16 bytes

  compress(data: Buffer | string) {
    const buf = Buffer.isBuffer(data) ? data : Buffer.from(data);
    return zlib.gzipSync(buf);
  }

  decompress(buf: Buffer) {
    return zlib.gunzipSync(buf);
  }

  encrypt(buf: Buffer) {
    const cipher = crypto.createCipheriv('aes-256-cbc', this.key, this.iv);
    return Buffer.concat([cipher.update(buf), cipher.final()]);
  }

  decrypt(buf: Buffer) {
    const decipher = crypto.createDecipheriv('aes-256-cbc', this.key, this.iv);
    return Buffer.concat([decipher.update(buf), decipher.final()]);
  }

  wrap(data: unknown): string {
    const json = Buffer.from(JSON.stringify(data));
    const zipped = this.compress(json);
    const enc = this.encrypt(zipped);
    return enc.toString('base64');
  }

  unwrap(b64: string): any {
    const enc = Buffer.from(b64, 'base64');
    const zipped = this.decrypt(enc);
    const json = this.decompress(zipped).toString('utf8');
    return JSON.parse(json);
  }
}
