import { PrismaClient } from '@prisma/client';
const prisma = new PrismaClient();

async function main() {
  const contact = await prisma.contact.upsert({
    where: { email: 'alice@example.com' },
    update: {},
    create: {
      fullName: 'Alice Example',
      email: 'alice@example.com',
      phone: '+1-555-0100',
      clientLicense: {
        create: {
          licenseKey: 'LIC-ALICE-0001',
          productType: 'MYAPP_PRO',
          channel: 'web',
          isBiller: true,
          expiresAt: new Date(Date.now() + 1000 * 60 * 60 * 24 * 365),
        },
      },
    },
  });
  console.log('Seeded:', { contact });
}

main().catch(console.error).finally(() => prisma.$disconnect());
