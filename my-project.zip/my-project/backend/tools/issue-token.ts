import 'dotenv/config';
import { NestFactory } from '@nestjs/core';
import { AppModule } from '../src/app.module';
import { LicenseService } from '../src/license/license.service';

async function run() {
  const app = await NestFactory.createApplicationContext(AppModule);
  const svc = app.get(LicenseService);
  const token = await svc.generateToken('LIC-ALICE-0001');
  console.log('license_token:', token);
  await app.close();
}
run();
