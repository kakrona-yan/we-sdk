// Node crypto/zlib aren't available in the browser directly.
// We'll use the Web Crypto API for AES-CBC and CompressionStream/DecompressionStream for gzip where supported.
// For simplicity in this demo, we'll fall back to server-less pack/unpack via small helpers in Node-compatible envs.
// In real apps, consider doing encryption in a worker or on the server before transit.

async function importKey(rawBytes: ArrayBuffer) {
  return crypto.subtle.importKey(
    'raw',
    rawBytes,
    { name: 'AES-CBC' },
    false,
    ['encrypt', 'decrypt']
  );
}

function b64ToBytes(b64: string) {
  const bin = atob(b64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return bytes;
}

function bytesToB64(bytes: Uint8Array) {
  let bin = '';
  for (let i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
  return btoa(bin);
}

// gzip using CompressionStream (Chromium/Edge). If unavailable, skip compression.
async function gzipBytes(bytes: Uint8Array): Promise<Uint8Array> {
  if (typeof CompressionStream !== 'undefined') {
    const cs = new CompressionStream('gzip');
    const writer = (new Response(new Blob([bytes]).stream().pipeThrough(cs))).arrayBuffer();
    return new Uint8Array(await writer);
  }
  return bytes;
}

async function gunzipBytes(bytes: Uint8Array): Promise<Uint8Array> {
  if (typeof DecompressionStream !== 'undefined') {
    const ds = new DecompressionStream('gzip');
    const writer = (new Response(new Blob([bytes]).stream().pipeThrough(ds))).arrayBuffer();
    return new Uint8Array(await writer);
  }
  return bytes;
}

export async function pack(obj: unknown): Promise<string> {
  const json = new TextEncoder().encode(JSON.stringify(obj));
  const zipped = await gzipBytes(json);
  const key = b64ToBytes(process.env.NEXT_PUBLIC_AES_KEY_BASE64!);
  const iv  = b64ToBytes(process.env.NEXT_PUBLIC_AES_IV_BASE64!);
  const cryptoKey = await importKey(key.buffer);
  const enc = await crypto.subtle.encrypt({ name: 'AES-CBC', iv }, cryptoKey, zipped);
  return bytesToB64(new Uint8Array(enc));
}

export async function unpack(b64: string): Promise<any> {
  const enc = b64ToBytes(b64);
  const key = b64ToBytes(process.env.NEXT_PUBLIC_AES_KEY_BASE64!);
  const iv  = b64ToBytes(process.env.NEXT_PUBLIC_AES_IV_BASE64!);
  const cryptoKey = await importKey(key.buffer);
  const dec = await crypto.subtle.decrypt({ name: 'AES-CBC', iv }, cryptoKey, enc);
  const unzipped = await gunzipBytes(new Uint8Array(dec));
  const text = new TextDecoder().decode(unzipped);
  return JSON.parse(text);
}

export async function secureFetch(url: string, options: RequestInit & { bodyObj?: any, licenseToken?: string } = {}) {
  const { bodyObj, licenseToken, headers, ...rest } = options;
  const hdrs = new Headers(headers || {});
  hdrs.set('content-type', 'application/json');
  hdrs.set('x-secure-payload', '1');
  if (licenseToken) hdrs.set('license_token', licenseToken);

  const body = bodyObj !== undefined ? JSON.stringify({ data: await pack(bodyObj) }) : undefined;
  const res = await fetch(url, { ...rest, method: rest.method || 'POST', headers: hdrs, body });
  const json = await res.json();
  if (!res.ok) throw new Error(json?.message || 'Request failed');
  if (json?.data) return await unpack(json.data);
  return json;
}
