'use client';

import { useState } from 'react';
import { secureFetch } from '../lib/secureTransport';

export default function Home() {
  const [token, setToken] = useState('');
  const [result, setResult] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  const getProtected = async () => {
    setError(null);
    try {
      const res = await fetch(process.env.NEXT_PUBLIC_API_BASE + '/protected/data', {
        method: 'GET',
        headers: { 'license_token': token }
      });
      const json = await res.json();
      setResult(json);
    } catch (e: any) {
      setError(e.message || 'failed');
    }
  };

  const postSecureEcho = async () => {
    setError(null);
    try {
      const data = await secureFetch(process.env.NEXT_PUBLIC_API_BASE + '/secure/echo', {
        bodyObj: { hello: 'world', time: Date.now() },
        licenseToken: token
      });
      setResult(data);
    } catch (e: any) {
      setError(e.message || 'failed');
    }
  };

  return (
    <main style={{ padding: 24, fontFamily: 'sans-serif' }}>
      <h1>License + Secure Transport Demo</h1>
      <p>Paste a valid <code>license_token</code> and try the calls.</p>
      <input
        type="text"
        placeholder="license_token"
        value={token}
        onChange={(e) => setToken(e.target.value)}
        style={{ width: '100%', padding: 8, marginBottom: 12 }}
      />
      <div style={{ display: 'flex', gap: 8 }}>
        <button onClick={getProtected}>GET /protected/data</button>
        <button onClick={postSecureEcho}>POST /secure/echo (AES+gzip)</button>
      </div>
      {error && <pre style={{ color: 'red' }}>{error}</pre>}
      {result && <pre style={{ background: '#f5f5f5', padding: 12 }}>{JSON.stringify(result, null, 2)}</pre>}
    </main>
  );
}
